## Changelog

### Update 12-1-2018 V3.6
1. Penambahan progrss bar.
2. Enable price use decimal (.).
3. Filter report by prefix.
4. Export user to script.
5. Export user to csv.
6. Penggantian kolom print menjadi tombol dan penambahan pilihan comment di user list.
7. Perubahan cara print voucher dari user list.
6. Beautify template editor dan penambahan tombol view voucher.

### Update 11-9-2018 V3.5
1. Penambahan chart traffic. Sesuaikan Max Rx dan Tx di Settings.
2. Penambahan pilihan filter di Report dan User Log. 

### Update 10-30-2018 V3.4
1. Penambahan cek spasi di nama user profile.
2. Penambahan user profile dan comment di Report. Yang perlu dilakukan adalah update user profile dari Mikhmon, buka user profile yang ingin diupdate kemudian klik Save. 
3. Penambahan filter berdasarkan server hotspot di Hotspot Active.

### Update 10-24-2018 V3.3
1. Perubahan struktur menu.
2. Penambahan Hotspot Cookie dan System Scheduler.
3. Perubahan Generate User. Menghilangkan huruf l,L,q,Q,o,O serta angka 1 dan 0.
4. Perbaikan remove user.

### Update 09-10-2018 V3.2
1. Penambahan kolom Time Left di Hotspot Active.
2. Penambahan Parent Queue di Add dan Edit User Profile (Bagaimana cara penggunaannya? silakan pelajari Simple Queue Mikrotik).
3. Penyesuaian format Data Limit user menjadi Byte Binary ([base 2](https://www.gbmb.org/gigabytes)).
4. Reformat Uptime.
